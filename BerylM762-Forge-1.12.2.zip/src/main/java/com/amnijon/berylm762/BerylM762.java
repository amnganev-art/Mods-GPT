package com.amnijon.berylm762;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod(modid=BerylM762.MODID, name=BerylM762.NAME, version=BerylM762.VERSION)
@EventBusSubscriber(modid=BerylM762.MODID)
public class BerylM762 {
 public static final String MODID="berylm762", NAME="Beryl M762", VERSION="1.0.0";
 public static Item BERYL_M762;
 @SubscribeEvent public static void registerItems(RegistryEvent.Register<Item> event) {
  BERYL_M762=new Item().setRegistryName(new ResourceLocation(MODID,"beryl_m762"))
   .setUnlocalizedName(MODID+".beryl_m762").setCreativeTab(CreativeTabs.COMBAT).setMaxStackSize(1);
  event.getRegistry().register(BERYL_M762);
 }
}
