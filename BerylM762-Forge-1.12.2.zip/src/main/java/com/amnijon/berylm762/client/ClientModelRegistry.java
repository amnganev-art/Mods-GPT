package com.amnijon.berylm762.client;
import com.amnijon.berylm762.BerylM762;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
@Mod.EventBusSubscriber(modid=BerylM762.MODID, value=net.minecraftforge.fml.relauncher.Side.CLIENT)
public class ClientModelRegistry {
 @SubscribeEvent public static void registerModels(ModelRegistryEvent event) {
  if(BerylM762.BERYL_M762!=null) ModelLoader.setCustomModelResourceLocation(
   BerylM762.BERYL_M762,0,new ModelResourceLocation(BerylM762.MODID+":beryl_m762","inventory"));
 }
}
